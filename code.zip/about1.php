<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>HKHES</title>
<!--css-->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--/css-->
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Travels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->		
<!-- js -->
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!-- /js -->
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700,300italic,400italic,500italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,700,300,600,800,400' rel='stylesheet' type='text/css'>
<!--/fonts-->
<!--script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
<!--/script-->
</head>
<body>
<!--header-->
<div class="header">
<div class="header-nav">
	<div class="container">
		<div class="logo"></div>
		<div class="navigation">
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"> </span>
						<span class="icon-bar"> </span>
						<span class="icon-bar"> </span>
					  </button>
					</div>
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					  <ul class="nav navbar-nav">
						<li><a href="index1.php">Home <span class="sr-only">(current)</span></a></li>
						<li class="active"><a href="about1.php">About</a></li>
						<li><a href="Chat1.php">Chat</a></li>
						<li><a href="blog1.php">Blog</a></li>
						<li><a href="gallery1.php">Goods</a></li>
						<li><a href="contact1.php">Contact Us</a></li>
					  </ul>
			  <div class="clearfix"> </div>
			</div><!-- /.navbar-collapse -->
		</nav>
	</div>
	</div>
	</div>
    <ul class="nav navbar-nav">
  <li><span class="selected"><i class=""><span>Hi,Eric</span><span><a href="index.php">Log out</a></span></i></span></li>
  
  
</ul>
<p>&nbsp;</p>
</div>
			  <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$(".top-nav ul").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
<div class="banner banner5">
</div>			
<!--inner-page-about-->
<div class="abouts">
		<div class="container">
			<h3>About Us</h3>
			<div class="about-main">
				<div class="about-top">
					<div class="col-md-5 about-top-left">
						<img src="images/a1.jpg" class="img-responsive" alt=""/>
					</div>
					<div class="col-md-7 about-top-right">
						<h4>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.</h4>
						<p>Fusce feugiat malesuada odio orbi nunc odio gravida at cursus nec luctus a lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna onec accumsan malesuada orci. Donec sit amet eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Mauris fermentum dictum magna. Sed laoreet aliquam leo.Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend.</p>
						<p>Bulum iaculis lacinia est. Proin dictum elemntum velit. Fusce euismod cons equat ante. Lorem ipsum dmeconsectetuer adipiscing elit. ellentesque sed dolor. Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla vene natis. In pede mi aliquet sit amet euismod in auctor ut ligula. </p>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>	 
	 <!------->
	 <div class="who_are">
	     <div class="container">			
				 <h5>WHO WE ARE</h5>
				 <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
				 <p>Morbi sapien turpis, aliquet quis elementum ut, molestie nec turpis. Duis ultrices fermentum enim ac facilisis. Phasellus laoreet rhoncus diam ut auctor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris ut malesuada mi. Aliquam nec est arcu. Quisque dui odio, interdum vel euismod vel, sollicitudin quis augue. Integer pharetra, neque in commodo consectetur, tortor enim venenatis nibh, sed dictum purus tortor non nisl.
				 Vestibulum in bibendum lacus. Suspendisse lobortis pharetra eros. Nam sagittis nulla sed lorem gravida laoreet. Sed id lacus erat. Sed ullamcorper, libero quis ultrices blandit, arcu lorem vehicula urna, ut ultrices nunc tortor a ex. Curabitur interdum sed leo quis condimentum. Nam congue erat elit, eu malesuada augue rutrum non. Donec malesuada ultrices commodo. Vestibulum commodo congue ipsum ac suscipit.</p>
			 
				 <div class="about-list">
					 <ul>
						 <li><a href="">Always free from repetition</a></li>
						 <li><a href="">Vestibulum rhoncus nibh quis dui fermentum iaculis.</a></li>
						 <li><a href="">The standard chunk of Lorem Ipsum</a></li>
						 <li><a href="">In consequat dolor in lorem egestas ultrices.</a></li>
						 <li><a href="">Aliquam sollicitudin eros id luctus consequat.</a></li>
						 <li class="none"><a href="">Always free from repetition</a></li>
					 </ul>		 
				 </div>			 
         </div>
	 </div>
<!-------></div>
<!--/inner-page-about-->
 <div class="footer">
			 <div class="container">				 	
				 <div class="col-md-3 ftr_navi ftr">
					 <h3>NAVIGATION</h3>
					 <ul>
						 <li><a href="index.php">Home</a></li>
						 <li><a href="about.php">About</a></li>
						 <li><a href="gallery.php">Gallery</a></li>						
						 <li><a href="blog.php">Blog</a></li>
						 <li><a href="contact.php">Contact</a></li>
					 </ul>
				 </div>
				 <div class="col-md-3 ftr_navi ftr">
					 <h3>MEMBERS</h3>
					 <ul>
						 <li><a href="#">Customer Support</a></li>
						 <li><a href="#">Platinum Support</a></li>
						 <li><a href="#">Gold Support</a></li>						
						 <li><a href="#">Standard Support</a></li>
						 <li><a href="#">Training</a></li>
					 </ul>
				 </div>
				 <div class="col-md-3 get_in_touch ftr">
					  <h3>GET IN TOUCH</h3>
					  <p>Ola-ola street jump,</p>
					  <p>260-14 City, Country</p>
					  <p>+62 000-0000-00</p>
					  <a href="mailto:mail@mlampah.com">www.example.com</a>
				 </div>
				 <div class="col-md-3 ftr-logo">
					 <a href="index.php"><h3>Travels</h3></a>
					 <p>© 2015 Travels. Design by <a href="http://w3layouts.com/">W3layouts</a></p>
				 </div>
				<div class="clearfix"> </div>
			 </div>
		  </div>
		 <!---End-container---->
		 <!---->
<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!----> 
</body>
</html>